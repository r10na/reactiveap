Follow Below steps for HotFix deployment.

A.ICM deployment
1.Follow ICM_TICKET_Deployment_Guide.docx

B.Billing deployment
1.Stop Billing application server
2.Apply patch:
 	
 	 -Replace process_flow_java.jar available at location MajescoBilling.ear\ICDService.war\WEB-INF\lib\process_flow_java.jar with given jar Jars\process_flow_java.jar
	
3.Start Billing application server



