Follow Below steps for HotFix deployment.
 (Added hotfix files of 5.5.0.4.3 to process_flow.jar)

A.Billing deployment   
1.Stop Billing application server
2.Apply patch:
 	
 	 -Replace process_flow.jar available at location MajescoBilling.ear\ICDService.war\WEB-INF\lib\process_flow.jar with given jar Jars\process_flow.jar	
	-Replace process_mapping_executor.jar available at location MajescoBilling.ear\ICDService.war\WEB-INF\lib\process_mapping_executor.jar with given jar Jars\process_mapping_executor.jar
	-Replace PolicyTermBalance.xml available at location MajescoBilling.ear\ICDService.war\WEB-INF\classes\objectmappings\PolicyTermBalance.xml with given xml  objectmapping\PolicyTermBalance.xml
		
3.Start Billing application server


















 

